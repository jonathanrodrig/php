<!DOCTYPE html>
<html>
 <head>
  <title>Prueba de PHP</title>
 </head>
 <body>
 <?php echo '<p>Hola Mundo</p>'; ?>
 <?php
 for ($i = 1; $i <= 10; $i++) {
    echo $i;
}
?>
 </body>
</html>